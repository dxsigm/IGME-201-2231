using System;
using Ch12CardLib;
using System.Collections;


namespace Ch12CardClient
{
   public class Player
   {
      private Cards hand;
      private string name;
	  private Cards CCards;
	  private Cards SCards;
	  private Cards HCards;
	  private Cards DCards;
	  private int TotalSuitSets;
	  private ArrayList SuitSetsArray;

      public string Name
      {
         get
         {
            return name;
         }
      }

      public Cards PlayHand
      {
         get
         {
            return hand;
         }
		  set
		  {
			  hand = value;
		  }

      }

      private Player()
      {

      }

      public Player(string newName)
      {
         name = newName;
         hand = new Cards();
		  CCards = new Cards();
		  SCards = new Cards();
		  HCards = new Cards();
		  DCards = new Cards();
		  TotalSuitSets = 0;
		  SuitSetsArray = new ArrayList();
	  }


	   private void SeperateSuits(Cards tempHand)
	   {
		   SuitSetsArray.Clear();
		   CCards.Clear();
		   SCards.Clear();
		   HCards.Clear();
		   DCards.Clear();
		   TotalSuitSets = 0;

		   foreach (Card card in tempHand)
		   {
			   int HC = card.GetHashCode();

			   if( HC < 14 )
				   CCards.Add(card);
			   if( (HC >= 14) && (HC < 27) )
				   SCards.Add(card);
			   if( (HC >= 27) && (HC < 40) )
				   HCards.Add(card);
			   if( HC >= 40 )
				   DCards.Add(card);
		   }

		   if(CCards.Count > 0)
		   {
			   SuitSetsArray.Add(CCards);
			   ++TotalSuitSets;
		   }
		   if(SCards.Count > 0)
		   {
			   SuitSetsArray.Add(SCards);
			   ++TotalSuitSets;
		   }
		   if(HCards.Count > 0)
		   {
			   SuitSetsArray.Add(HCards);
			   ++TotalSuitSets;
		   }
		   if(DCards.Count > 0)
		   {
			   SuitSetsArray.Add(DCards);
			   ++TotalSuitSets;
		   }
	   }

	   void Display(Cards cards,String tmp)
	   {
		  Console.WriteLine(tmp);
		   foreach(Card card in cards)
		   {
			   Console.WriteLine(card);
		   }

		   for(int i = 0 ; i < TotalSuitSets; i ++)
		   {
			   Console.WriteLine("///SUIT///{0}//////",i);
			   Cards d = (Cards)SuitSetsArray[i];
			   foreach(Card card in d)
			   {
				   Console.WriteLine(card);
			   }
		   }
		   Console.WriteLine("//////END//////");
	   }

	   public bool HasWon()
	   {
		   Cards tempHand = (Cards)hand.Clone();
		   hand.SortedSet(tempHand);
				

		   bool threeSeq = false;
		   SeperateSuits(tempHand);

		   for(int SuitCount = 0; SuitCount  < TotalSuitSets; SuitCount ++)
		   {
			   Cards TempHand = (Cards)SuitSetsArray[SuitCount];

			   if(TempHand.Count > 0)
			   {
				   if(TempHand.Count == 7)
				   {
					   if(isSequentialNew(TempHand))
					   {
						   return true;
					   }
					   else
					   {
						   int maxVal, minVal;
						   GetLimits(tempHand, out maxVal, out minVal);
						   for (int cardIndex = tempHand.Count - 1; cardIndex >= 0; cardIndex--)
						   {
							   if (((int)tempHand[cardIndex].rank < (minVal + 3))
								   || ((int)tempHand[cardIndex].rank > (maxVal - 3)))
							   {
								   tempHand.RemoveAt(cardIndex);
							   }
						   }
						   if (tempHand.Count != 1)
						   {
							   return false;
						   }
						   if ((tempHand[0].rank == (Rank)(minVal + 3))
							   || (tempHand[0].rank == (Rank)(maxVal - 3)))
						   {
							   return true;
						   }
						   else
						   {
							   return false;
						   }
  
					   }
						if((TempHand.Count == 5) || (TempHand.Count == 6))
							return false;

						if((TempHand.Count == 3))
						{
							if(isSequentialNew(TempHand))
							{
								threeSeq = true;
								SuitSetsArray.RemoveAt(SuitCount);
								--TotalSuitSets;
								for (int cardIndex = tempHand.Count-1,setIndex = TempHand.Count-1; cardIndex >= 0; cardIndex--)
								{
									if ((TempHand[setIndex].GetHashCode()) 
										== (tempHand[cardIndex].GetHashCode()))
									{
										tempHand.RemoveAt(cardIndex);
										setIndex--;
									}
								}
							}
						}
					   SeperateSuits(tempHand);
				   }	
			   }	
		   }			

		   bool fourOfAKind = false;
		   bool threeOfAKind = false;
		   int fourRank = -1;
		   int threeRank = -1;

		   int cardsOfRank;
		   for (int matchRank = 0; matchRank < 13; matchRank++)
		   {
			   cardsOfRank = 0;
			   foreach (Card c in tempHand)
			   {
				   if (c.rank == (Rank)matchRank)
				   {
					   cardsOfRank++;
				   }
			   }
			   if (cardsOfRank == 4)
			   {
				   fourRank = matchRank;
				   fourOfAKind = true;
			   }
			   if (cardsOfRank == 3)
			   {
				   if (threeOfAKind == true)
				   {
					   return false;
				   }
				   threeRank = matchRank;
				   threeOfAKind = true;
			   }
		   }

		   if(threeSeq && fourOfAKind)
			   return true;

		   if (threeOfAKind && fourOfAKind)
		   {
			   if(threeRank == fourRank)
				   threeOfAKind = false;
			   else
				   return true;
		   }

		   if (threeOfAKind)
		   {
			   for (int cardIndex = tempHand.Count - 1; cardIndex >= 0; cardIndex--)
			   {
				   if ((tempHand[cardIndex].rank == (Rank)threeRank))
				   {
					   tempHand.RemoveAt(cardIndex);
				   }
			   }
			   SeperateSuits(tempHand);
		   }

		   for(int SuitCount = 0; SuitCount  < TotalSuitSets; SuitCount ++)
		   {
			   Cards TempHand = (Cards)SuitSetsArray[SuitCount];
			   if((TempHand.Count == 4))
			   {
				   if(isSequentialNew(TempHand))
				   {
					   SuitSetsArray.RemoveAt(SuitCount);
					   --TotalSuitSets;
					   for (int cardIndex = tempHand.Count-1,setIndex = TempHand.Count-1; cardIndex >= 0; cardIndex--)
					   {
						   if ((TempHand[setIndex].GetHashCode()) 
							   == (tempHand[cardIndex].GetHashCode()))
						   {
							   tempHand.RemoveAt(cardIndex);
							   setIndex--;
						   }
					   }
					   if(tempHand.Count == 0)
						   return true;
					   SeperateSuits(tempHand);
				   }
			   }
		   }


		   threeOfAKind = false;
		   fourOfAKind = false;

		   for (int matchRank = 0; matchRank < 13; matchRank++)
		   {
			   cardsOfRank = 0;
			   foreach (Card c in tempHand)
			   {
				   if (c.rank == (Rank)matchRank)
				   {
					   cardsOfRank++;
				   }
			   }
			   if (cardsOfRank == 4)
			   {
				   fourRank = matchRank;
				   fourOfAKind = true;
			   }
			   if (cardsOfRank == 3)
			   {
				   if (threeOfAKind == true)
				   {
					   return false;
				   }
				   threeRank = matchRank;
				   threeOfAKind = true;
			   }
		   }

		   if (fourOfAKind)
		   {
			   for (int cardIndex = tempHand.Count - 1; cardIndex >= 0; cardIndex--)
			   {
				   if ((tempHand[cardIndex].rank == (Rank)fourRank))
				   {
					   tempHand.RemoveAt(cardIndex);
				   }
			   }
		   }

		   if(tempHand.Count == 0)
			   return true;

		   if(tempHand.Count > 3)
			   return false;

		   if(isSequentialNew(tempHand))
		   {
			   return true;
		   }

		   if(tempHand[0].rank == tempHand[1].rank && tempHand[1].rank == tempHand[2].rank)
		   {
			   return true;
		   }

		   return false;
	   }

	   private void GetLimits(Cards cards, out int maxVal, out int minVal)
	   {
		   maxVal = 0;
		   minVal = 14;
		   foreach (Card card in cards)
		   {
			   if ((int)card.rank > maxVal)
			   {
				   maxVal = (int)card.rank;
			   }
			   if ((int)card.rank < minVal)
			   {
				   minVal = (int)card.rank;
			   }
		   }
	   }

	   private bool isSequential(Cards cards)
	   {
		   int maxVal, minVal;
		   GetLimits(cards, out maxVal, out minVal);
		   if ((maxVal - minVal) == (cards.Count - 1))
		   {
			   return true;
		   }
		   else
		   {
			   return false;
		   }
	   }
	   private bool isSequentialNew(Cards cards)
	   {
		   int maxVal, minVal;

		   /*****/
		   maxVal = 0;
		   minVal = 52;
		   foreach (Card card in cards)
		   {
			   int HashCode = card.GetHashCode();
			   if (HashCode > maxVal)
			   {
				   maxVal = card.GetHashCode();
			   }
			   if (HashCode  < minVal)
			   {
				   minVal = card.GetHashCode();
			   }
		   }

		   /*****/
		   if ((maxVal - minVal) == (cards.Count - 1))
		   {
			   return true;
		   }
		   else
		   {
			   return false;
		   }
	   }

   }
}

